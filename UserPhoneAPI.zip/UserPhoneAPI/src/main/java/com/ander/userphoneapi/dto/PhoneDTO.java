package com.ander.userphoneapi.dto;

public record PhoneDTO(Long id, String number) {}